package com.edulearn.lesson.controller;

import com.edulearn.lesson.dto.*;
import com.edulearn.lesson.service.LessonService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/lessons")
@RequiredArgsConstructor
public class LessonController {

    private final LessonService lessonService;

    @PostMapping
    public ResponseEntity<LessonResponse> addLesson(@Valid @RequestBody LessonRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(lessonService.addLesson(request));
    }

    @GetMapping("/course/{courseId}")
    public ResponseEntity<List<LessonResponse>> getLessonsByCourse(@PathVariable UUID courseId) {
        return ResponseEntity.ok(lessonService.getLessonsByCourse(courseId));
    }

    @GetMapping("/{lessonId}")
    public ResponseEntity<LessonResponse> getLessonById(@PathVariable UUID lessonId) {
        return ResponseEntity.ok(lessonService.getLessonById(lessonId));
    }

    @PutMapping("/{lessonId}")
    public ResponseEntity<LessonResponse> updateLesson(
            @PathVariable UUID lessonId,
            @Valid @RequestBody LessonRequest request
    ) {
        return ResponseEntity.ok(lessonService.updateLesson(lessonId, request));
    }

    @DeleteMapping("/{lessonId}")
    public ResponseEntity<Void> deleteLesson(@PathVariable UUID lessonId) {
        lessonService.deleteLesson(lessonId);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/course/{courseId}/reorder")
    public ResponseEntity<List<LessonResponse>> reorderLessons(
            @PathVariable UUID courseId,
            @Valid @RequestBody List<LessonOrderUpdateRequest> requests
    ) {
        return ResponseEntity.ok(lessonService.reorderLessons(courseId, requests));
    }

    @PostMapping("/{lessonId}/resources")
    public ResponseEntity<ResourceResponse> addResource(
            @PathVariable UUID lessonId,
            @Valid @RequestBody ResourceRequest request
    ) {
        return ResponseEntity.status(HttpStatus.CREATED).body(lessonService.addResource(lessonId, request));
    }

    @DeleteMapping("/resources/{resourceId}")
    public ResponseEntity<Void> removeResource(@PathVariable UUID resourceId) {
        lessonService.removeResource(resourceId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/course/{courseId}/preview")
    public ResponseEntity<List<LessonResponse>> getPreviewLessons(@PathVariable UUID courseId) {
        return ResponseEntity.ok(lessonService.getPreviewLessons(courseId));
    }

    @GetMapping("/ping")
    public ResponseEntity<String> ping() {
        return ResponseEntity.ok("Lesson service is working");
    }
}