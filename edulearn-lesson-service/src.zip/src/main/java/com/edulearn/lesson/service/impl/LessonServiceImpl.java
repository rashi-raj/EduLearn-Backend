package com.edulearn.lesson.service.impl;

import com.edulearn.lesson.dto.*;
import com.edulearn.lesson.entity.Lesson;
import com.edulearn.lesson.entity.Resource;
import com.edulearn.lesson.repository.LessonRepository;
import com.edulearn.lesson.repository.ResourceRepository;
import com.edulearn.lesson.service.LessonService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class LessonServiceImpl implements LessonService {

    private final LessonRepository lessonRepository;
    private final ResourceRepository resourceRepository;

    @Override
    public LessonResponse addLesson(LessonRequest request) {
        Lesson lesson = Lesson.builder()
                .courseId(request.getCourseId())
                .title(request.getTitle())
                .contentType(request.getContentType())
                .contentUrl(request.getContentUrl())
                .durationMinutes(request.getDurationMinutes())
                .orderIndex(request.getOrderIndex())
                .description(request.getDescription())
                .isPreview(request.getIsPreview())
                .build();

        return mapToLessonResponse(lessonRepository.save(lesson));
    }

    @Override
    public List<LessonResponse> getLessonsByCourse(UUID courseId) {
        return lessonRepository.findByCourseIdOrderByOrderIndexAsc(courseId)
                .stream()
                .map(this::mapToLessonResponse)
                .toList();
    }

    @Override
    public LessonResponse getLessonById(UUID lessonId) {
        Lesson lesson = lessonRepository.findById(lessonId)
                .orElseThrow(() -> new RuntimeException("Lesson not found"));
        return mapToLessonResponse(lesson);
    }

    @Override
    public LessonResponse updateLesson(UUID lessonId, LessonRequest request) {
        Lesson lesson = lessonRepository.findById(lessonId)
                .orElseThrow(() -> new RuntimeException("Lesson not found"));

        lesson.setCourseId(request.getCourseId());
        lesson.setTitle(request.getTitle());
        lesson.setContentType(request.getContentType());
        lesson.setContentUrl(request.getContentUrl());
        lesson.setDurationMinutes(request.getDurationMinutes());
        lesson.setOrderIndex(request.getOrderIndex());
        lesson.setDescription(request.getDescription());
        lesson.setIsPreview(request.getIsPreview());

        return mapToLessonResponse(lessonRepository.save(lesson));
    }

    @Override
    public void deleteLesson(UUID lessonId) {
        if (!lessonRepository.existsById(lessonId)) {
            throw new RuntimeException("Lesson not found");
        }
        resourceRepository.deleteByLessonId(lessonId);
        lessonRepository.deleteById(lessonId);
    }

    @Override
    public List<LessonResponse> reorderLessons(UUID courseId, List<LessonOrderUpdateRequest> requests) {
        List<Lesson> lessons = lessonRepository.findByCourseId(courseId);

        for (Lesson lesson : lessons) {
            requests.stream()
                    .filter(r -> r.getLessonId().equals(lesson.getLessonId()))
                    .findFirst()
                    .ifPresent(r -> lesson.setOrderIndex(r.getOrderIndex()));
        }

        lessonRepository.saveAll(lessons);

        return lessonRepository.findByCourseIdOrderByOrderIndexAsc(courseId)
                .stream()
                .map(this::mapToLessonResponse)
                .toList();
    }

    @Override
    public ResourceResponse addResource(UUID lessonId, ResourceRequest request) {
        lessonRepository.findById(lessonId)
                .orElseThrow(() -> new RuntimeException("Lesson not found"));

        Resource resource = Resource.builder()
                .lessonId(lessonId)
                .name(request.getName())
                .fileUrl(request.getFileUrl())
                .fileType(request.getFileType())
                .sizeKb(request.getSizeKb())
                .build();

        return mapToResourceResponse(resourceRepository.save(resource));
    }

    @Override
    public void removeResource(UUID resourceId) {
        if (!resourceRepository.existsById(resourceId)) {
            throw new RuntimeException("Resource not found");
        }
        resourceRepository.deleteById(resourceId);
    }

    @Override
    public List<LessonResponse> getPreviewLessons(UUID courseId) {
        return lessonRepository.findByCourseIdAndIsPreviewTrueOrderByOrderIndexAsc(courseId)
                .stream()
                .map(this::mapToLessonResponse)
                .toList();
    }

    private LessonResponse mapToLessonResponse(Lesson lesson) {
        List<ResourceResponse> resources = resourceRepository.findByLessonId(lesson.getLessonId())
                .stream()
                .map(this::mapToResourceResponse)
                .toList();

        return LessonResponse.builder()
                .lessonId(lesson.getLessonId())
                .courseId(lesson.getCourseId())
                .title(lesson.getTitle())
                .contentType(lesson.getContentType())
                .contentUrl(lesson.getContentUrl())
                .durationMinutes(lesson.getDurationMinutes())
                .orderIndex(lesson.getOrderIndex())
                .description(lesson.getDescription())
                .isPreview(lesson.getIsPreview())
                .resources(resources)
                .build();
    }

    private ResourceResponse mapToResourceResponse(Resource resource) {
        return ResourceResponse.builder()
                .resourceId(resource.getResourceId())
                .lessonId(resource.getLessonId())
                .name(resource.getName())
                .fileUrl(resource.getFileUrl())
                .fileType(resource.getFileType())
                .sizeKb(resource.getSizeKb())
                .build();
    }
}