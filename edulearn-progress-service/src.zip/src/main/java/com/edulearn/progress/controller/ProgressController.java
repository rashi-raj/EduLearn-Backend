package com.edulearn.progress.controller;

import com.edulearn.progress.dto.CertificateResponse;
import com.edulearn.progress.dto.CompleteLessonRequest;
import com.edulearn.progress.dto.ProgressResponse;
import com.edulearn.progress.service.ProgressService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/progress")
@RequiredArgsConstructor
public class ProgressController {

    private final ProgressService progressService;

    @PostMapping("/complete-lesson")
    public ResponseEntity<Void> completeLesson(@RequestBody @Valid CompleteLessonRequest request) {
        progressService.completeLesson(
                request.getStudentId(),
                request.getCourseId(),
                request.getLessonId()
        );
        return ResponseEntity.ok().build();
    }

    @GetMapping
    public ResponseEntity<ProgressResponse> getProgress(
            @RequestParam UUID studentId,
            @RequestParam UUID courseId
    ) {
        return ResponseEntity.ok(
                progressService.getProgress(studentId, courseId)
        );
    }

    @GetMapping("/ping")
    public ResponseEntity<String> ping() {
        return ResponseEntity.ok("Progress service is working");
    }
}